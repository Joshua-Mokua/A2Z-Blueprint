"""pages/19_credit_monitoring.py — Credit Monitoring System."""
import streamlit as st
import pandas as pd
import json
from pathlib import Path
from datetime import date, datetime, timedelta
from pages._shared import load_shared_state
from pages._access import require_access

require_access("credit_monitoring")

um, ud, uname, em, ri_pm, prod_m, pm, lm, hr_m, casc, vm, rlm = load_shared_state()

DATA = Path(__file__).parent.parent / "data"

_bank = st.session_state.get("_bank_display", "A2Z Blueprint")
_curr = st.session_state.get("_currency", "KES")

st.markdown(
    f"<div style='padding:14px 20px;background:var(--brand-primary,#006B3F);"
    f"border-radius:10px;margin-bottom:16px'>"
    f"<div style='color:white;font-size:15px;font-weight:600'>Credit Monitoring System</div>"
    f"<div style='color:rgba(255,255,255,0.65);font-size:11px'>"
    f"Watchlist · Covenant Tracking · NPL Migration · Portfolio at Risk</div></div>",
    unsafe_allow_html=True)

# ── Load data ──────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def load_cm():
    p = DATA / "credit_monitoring.json"
    if not p.exists():
        return {"watchlist": [], "last_updated": ""}
    return json.loads(p.read_text())

cm_data   = load_cm()
watchlist = cm_data.get("watchlist", [])

if not watchlist:
    st.info("No credit monitoring data. Generate CBS data first.")
    st.stop()

# ── Tabs ───────────────────────────────────────────────────────────────
cm_tabs = st.tabs([
    "📊 Portfolio overview",
    "📋 Watchlist",
    "⚠️ Covenant tracking",
    "📈 NPL migration",
    "🏦 Branch / RM view",
])

# ════════════════════════════════════════════════════════════════
# TAB 0: PORTFOLIO OVERVIEW
# ════════════════════════════════════════════════════════════════
with cm_tabs[0]:
    df = pd.DataFrame(watchlist)

    total_exposure  = df["outstanding"].sum()
    total_accounts  = len(df)
    loss_exposure   = df[df["classification"]=="Loss"]["outstanding"].sum()
    doubtful_exp    = df[df["classification"]=="Doubtful"]["outstanding"].sum()
    watch_exp       = df[df["classification"]=="Watch"]["outstanding"].sum()
    npl_ratio       = (loss_exposure + doubtful_exp) / (total_exposure or 1) * 100
    stage3_count    = len(df[df["stage"]=="Stage 3"])
    stage2_count    = len(df[df["stage"]=="Stage 2"])
    overdue_reviews = len(df[df["next_review_due"] < str(date.today())])

    # Metrics strip
    m1,m2,m3,m4,m5,m6 = st.columns(6)
    m1.metric("Watchlist accounts", f"{total_accounts:,}")
    m2.metric("Total exposure",     f"{_curr} {total_exposure/1e9:.2f}B")
    m3.metric("NPL ratio",          f"{npl_ratio:.1f}%",
              delta=f"+{npl_ratio-9:.1f}% vs 9% target", delta_color="inverse")
    m4.metric("Stage 3 (Loss)",     f"{stage3_count:,}")
    m5.metric("Stage 2 (Doubtful)", f"{stage2_count:,}")
    m6.metric("Overdue reviews",    f"{overdue_reviews:,}",
              delta=f"-{overdue_reviews}" if overdue_reviews else None, delta_color="inverse")

    st.markdown("---")
    cl1, cl2 = st.columns(2)

    # Classification breakdown
    with cl1:
        st.markdown("#### By classification")
        clf_data = df.groupby("classification").agg(
            Accounts=("id","count"),
            Outstanding=("outstanding","sum"),
        ).reset_index().sort_values("Outstanding", ascending=False)
        clf_data["Outstanding"] = clf_data["Outstanding"].apply(
            lambda x: f"{_curr} {x/1e9:.3f}B")
        clf_data["% of Total"] = df.groupby("classification")["outstanding"].sum() \
            .apply(lambda x: f"{x/total_exposure*100:.1f}%").values
        st.dataframe(clf_data, hide_index=True, use_container_width=True)

    # PAR bucket
    with cl2:
        st.markdown("#### PAR buckets")
        def par_bucket(days):
            if days <= 30:   return "1-30 days"
            elif days <= 60: return "31-60 days"
            elif days <= 90: return "61-90 days"
            elif days <= 180:return "91-180 days"
            else:            return ">180 days"
        df["PAR Bucket"] = df["npl_days"].apply(par_bucket)
        par_data = df.groupby("PAR Bucket").agg(
            Accounts=("id","count"),
            Outstanding=("outstanding","sum"),
        ).reset_index()
        bucket_order = ["1-30 days","31-60 days","61-90 days","91-180 days",">180 days"]
        par_data["PAR Bucket"] = pd.Categorical(par_data["PAR Bucket"], categories=bucket_order, ordered=True)
        par_data = par_data.sort_values("PAR Bucket")
        par_data["Outstanding"] = par_data["Outstanding"].apply(lambda x: f"{_curr} {x/1e9:.3f}B")
        st.dataframe(par_data, hide_index=True, use_container_width=True)

    # Stage distribution
    st.markdown("#### IFRS 9 staging")
    sg1,sg2,sg3 = st.columns(3)
    for col, stage, clr, desc in [
        (sg1,"Stage 1","#3B6D11","Performing — 12-month ECL"),
        (sg2,"Stage 2","#BA7517","Significant credit deterioration — Lifetime ECL"),
        (sg3,"Stage 3","#A32D2D","Credit-impaired — Lifetime ECL"),
    ]:
        stage_df = df[df["stage"]==stage]
        count = len(stage_df)
        exp   = stage_df["outstanding"].sum()
        col.markdown(
            f"<div style='padding:12px 14px;border-left:4px solid {clr};"
            f"background:var(--color-background-secondary);border-radius:0 8px 8px 0'>"
            f"<div style='font-size:11px;color:{clr};font-weight:600'>{stage}</div>"
            f"<div style='font-size:20px;font-weight:600'>{count:,}</div>"
            f"<div style='font-size:12px;color:var(--color-text-secondary)'>"
            f"{_curr} {exp/1e9:.2f}B exposure</div>"
            f"<div style='font-size:11px;color:var(--color-text-tertiary)'>{desc}</div>"
            f"</div>", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# TAB 1: WATCHLIST
# ════════════════════════════════════════════════════════════════
with cm_tabs[1]:
    df = pd.DataFrame(watchlist)

    # Filters
    fc1,fc2,fc3,fc4 = st.columns(4)
    clf_filt    = fc1.selectbox("Classification",
        ["All","Watch","Substandard","Doubtful","Loss"], key="cm_clf")
    stage_filt  = fc2.selectbox("Stage",
        ["All","Stage 1","Stage 2","Stage 3"], key="cm_stage")
    region_filt = fc3.selectbox("Region",
        ["All"] + sorted(df["region"].dropna().unique().tolist()), key="cm_reg")
    search      = fc4.text_input("Search account / RM", key="cm_search")

    mask = pd.Series([True]*len(df))
    if clf_filt   != "All": mask &= df["classification"]==clf_filt
    if stage_filt != "All": mask &= df["stage"]==stage_filt
    if region_filt!= "All": mask &= df["region"]==region_filt
    if search.strip():
        s = search.strip().lower()
        mask &= (df["account_number"].str.lower().str.contains(s) |
                 df["rm_name"].str.lower().str.contains(s,na=False))

    fdf = df[mask].copy()
    st.caption(f"Showing {len(fdf):,} of {len(df):,} watchlist accounts")

    # Colour-code by classification
    def clf_clr(v):
        m = {"Loss":"color:#A32D2D;font-weight:500",
             "Doubtful":"color:#854F0B;font-weight:500",
             "Substandard":"color:#BA7517",
             "Watch":"color:#185FA5"}
        return m.get(v,"")

    show = fdf[["id","account_number","branch_name","region","rm_name",
                "classification","stage","npl_days","outstanding",
                "collateral_value","next_review_due"]].copy()
    show["outstanding"]     = show["outstanding"].apply(lambda x: f"{x/1e6:.1f}M")
    show["collateral_value"]= show["collateral_value"].apply(lambda x: f"{x/1e6:.1f}M")
    show = show.rename(columns={
        "account_number":"Account","branch_name":"Branch","rm_name":"RM",
        "classification":"Class","stage":"Stage","npl_days":"NPL Days",
        "outstanding":"Outstanding","collateral_value":"Collateral",
        "next_review_due":"Next Review"})

    st.dataframe(
        show.style.map(clf_clr, subset=["Class"]),
        hide_index=True, use_container_width=True, height=420)

    # Detail expander for selected account
    st.markdown("---")
    st.markdown("#### Account detail")
    acct_opts = ["— Select account —"] + fdf["account_number"].tolist()[:200]
    sel_acct  = st.selectbox("Account number", acct_opts, key="cm_acct_sel")
    if sel_acct != "— Select account —":
        rec = next((w for w in watchlist if w["account_number"]==sel_acct), None)
        if rec:
            d1,d2,d3 = st.columns(3)
            d1.markdown(f"**RM:** {rec['rm_name']}")
            d1.markdown(f"**Branch:** {rec['branch_name']}, {rec['region']}")
            d1.markdown(f"**Classification:** {rec['classification']} · {rec['stage']}")
            d2.markdown(f"**Outstanding:** {_curr} {rec['outstanding']/1e6:.2f}M")
            d2.markdown(f"**Loan amount:** {_curr} {rec['loan_amount']/1e6:.2f}M")
            d2.markdown(f"**Collateral:** {rec['collateral_type']} — {_curr} {rec['collateral_value']/1e6:.2f}M")
            d3.markdown(f"**NPL days:** {rec['npl_days']}")
            d3.markdown(f"**Date added:** {rec['date_added']}")
            d3.markdown(f"**Next review:** {rec['next_review_due']}")

            # Covenants
            if rec.get("covenants"):
                st.markdown("**Covenants:**")
                cov_df = pd.DataFrame(rec["covenants"])
                def cov_clr(v):
                    if "Major" in str(v): return "color:#A32D2D;font-weight:500"
                    if "Minor" in str(v): return "color:#BA7517"
                    if "Compliant" in str(v): return "color:#3B6D11"
                    return ""
                st.dataframe(cov_df.style.map(cov_clr, subset=["status"]),
                             hide_index=True, use_container_width=True)

            # Add note
            with st.form(f"cm_note_{sel_acct}"):
                note = st.text_area("Add review note", height=80, key=f"cm_note_txt_{sel_acct}")
                if st.form_submit_button("💾 Save note"):
                    for w in watchlist:
                        if w["account_number"] == sel_acct:
                            w["notes"] = note
                            w["last_reviewed"] = str(date.today())
                    cm_data["watchlist"] = watchlist
                    (DATA/"credit_monitoring.json").write_text(json.dumps(cm_data, indent=2))
                    load_cm.clear()
                    st.success("Note saved.")
                    st.rerun()

# ════════════════════════════════════════════════════════════════
# TAB 2: COVENANT TRACKING
# ════════════════════════════════════════════════════════════════
with cm_tabs[2]:
    # Flatten covenants
    cov_rows = []
    for w in watchlist:
        for c in w.get("covenants", []):
            cov_rows.append({
                "Account":    w["account_number"],
                "Branch":     w["branch_name"],
                "RM":         w["rm_name"],
                "Class":      w["classification"],
                "Covenant":   c["type"],
                "Status":     c["status"],
                "Next Review":c["next_review"],
                "Outstanding":w["outstanding"],
            })

    cov_df = pd.DataFrame(cov_rows) if cov_rows else pd.DataFrame()

    if cov_df.empty:
        st.info("No covenant data.")
    else:
        # Summary
        cc1,cc2,cc3,cc4 = st.columns(4)
        total_cov  = len(cov_df)
        major_breach = len(cov_df[cov_df["Status"]=="Breach - Major"])
        minor_breach = len(cov_df[cov_df["Status"]=="Breach - Minor"])
        waiver      = len(cov_df[cov_df["Status"]=="Waiver Granted"])
        overdue_cov = len(cov_df[cov_df["Next Review"] < str(date.today())])

        cc1.metric("Total covenants",  f"{total_cov:,}")
        cc2.metric("Major breaches",   f"{major_breach:,}",
                   delta=f"-{major_breach}" if major_breach else None, delta_color="inverse")
        cc3.metric("Minor breaches",   f"{minor_breach:,}")
        cc4.metric("Overdue reviews",  f"{overdue_cov:,}")

        st.markdown("---")
        # Filter to breaches only by default
        breach_only = st.checkbox("Show breaches only", value=True, key="cov_breach")
        disp_cov = cov_df[cov_df["Status"].str.contains("Breach")] if breach_only else cov_df

        def cov_style(v):
            if "Major" in str(v): return "color:#A32D2D;font-weight:500"
            if "Minor" in str(v): return "color:#BA7517"
            if "Compliant" in str(v): return "color:#3B6D11"
            if "Waiver" in str(v):    return "color:#185FA5"
            return ""

        disp_cov = disp_cov.sort_values("Next Review")
        disp_cov["Outstanding"] = disp_cov["Outstanding"].apply(lambda x: f"{x/1e6:.1f}M")
        st.dataframe(disp_cov.style.map(cov_style, subset=["Status"]),
                     hide_index=True, use_container_width=True, height=400)

        st.download_button("📥 Export breaches",
            data=disp_cov.to_csv(index=False).encode(),
            file_name="covenant_breaches.csv", mime="text/csv", key="cov_export")

# ════════════════════════════════════════════════════════════════
# TAB 3: NPL MIGRATION
# ════════════════════════════════════════════════════════════════
with cm_tabs[3]:
    st.caption("Track how accounts migrate between classification buckets over time.")
    df = pd.DataFrame(watchlist)

    # Compute migration matrix — simulated from npl_days distribution
    def current_bucket(days):
        if days <= 30:   return "Watch"
        elif days <= 90: return "Substandard"
        elif days <= 180:return "Doubtful"
        else:            return "Loss"

    # Show current vs previous (simulated: previous = current + random movement)
    migration_rows = []
    for cat_from in ["Watch","Substandard","Doubtful","Loss"]:
        from_df = df[df["classification"]==cat_from]
        stayed  = int(len(from_df) * 0.70)
        upgraded= int(len(from_df) * 0.10)
        downgraded = len(from_df) - stayed - upgraded
        migration_rows.append({
            "From \\ To →": cat_from,
            "Watch":         stayed if cat_from=="Watch" else 0,
            "Substandard":   downgraded if cat_from=="Watch" else (stayed if cat_from=="Substandard" else 0),
            "Doubtful":      downgraded if cat_from=="Substandard" else (stayed if cat_from=="Doubtful" else 0),
            "Loss":          downgraded if cat_from in ("Doubtful","Loss") else 0,
            "Recovered":     upgraded,
        })

    mig_df = pd.DataFrame(migration_rows).set_index("From \\ To →")
    st.markdown("#### Migration matrix (current month estimate)")
    st.caption("Rows = starting classification · Columns = ending classification")

    def heatmap_style(v):
        if isinstance(v, (int, float)) and v > 0:
            if v > 100: return "background:#FCEBEB;color:#A32D2D"
            if v > 50:  return "background:#FAEEDA;color:#854F0B"
            return "background:#EAF3DE;color:#3B6D11"
        return ""

    st.dataframe(mig_df.style.map(heatmap_style), use_container_width=True)

    st.markdown("---")
    # NPL trend by classification
    st.markdown("#### Current NPL exposure by classification")
    trend = df.groupby("classification")["outstanding"].sum().reset_index()
    trend.columns = ["Classification","Outstanding (KES)"]
    trend["Outstanding (KES)"] = trend["Outstanding (KES)"].apply(lambda x: f"{x/1e9:.3f}B")
    trend["Accounts"] = df.groupby("classification")["id"].count().values
    target_npl = df["outstanding"].sum() * 0.09  # 9% target
    actual_npl = df[df["classification"].isin(["Doubtful","Loss"])]["outstanding"].sum()
    gap = actual_npl - target_npl
    if gap > 0:
        st.warning(
            f"🔴 NPL exposure KES {actual_npl/1e9:.2f}B exceeds 9% target "
            f"(KES {target_npl/1e9:.2f}B) by KES {gap/1e9:.2f}B")
    else:
        st.success(f"✅ NPL exposure within target.")
    st.dataframe(trend, hide_index=True, use_container_width=True)

# ════════════════════════════════════════════════════════════════
# TAB 4: BRANCH / RM VIEW
# ════════════════════════════════════════════════════════════════
with cm_tabs[4]:
    df = pd.DataFrame(watchlist)

    view = st.radio("View by", ["Branch","Region","RM"], horizontal=True, key="cm_view")

    if view == "Branch":
        grp = df.groupby("branch_name")
    elif view == "Region":
        grp = df.groupby("region")
    else:
        grp = df.groupby("rm_name")

    summary = grp.agg(
        Accounts=("id","count"),
        NPL_Exposure=("outstanding","sum"),
        Loss_Accounts=("classification", lambda x: (x=="Loss").sum()),
        Avg_Days=("npl_days","mean"),
    ).reset_index()
    summary.columns = [view,"Accounts","NPL Exposure","Loss Accounts","Avg NPL Days"]
    summary["NPL Exposure"] = summary["NPL Exposure"].apply(lambda x: f"{_curr} {x/1e6:.1f}M")
    summary["Avg NPL Days"] = summary["Avg NPL Days"].apply(lambda x: f"{x:.0f}")
    summary = summary.sort_values("Loss Accounts", ascending=False).head(50)

    def loss_clr(v):
        try:
            n = int(v)
            if n > 20: return "color:#A32D2D;font-weight:500"
            if n > 5:  return "color:#BA7517"
        except: pass
        return ""

    st.dataframe(
        summary.style.map(loss_clr, subset=["Loss Accounts"]),
        hide_index=True, use_container_width=True, height=420)

    st.download_button("📥 Export",
        data=summary.to_csv(index=False).encode(),
        file_name=f"npl_{view.lower()}_view.csv", mime="text/csv",
        key="cm_branch_export")
